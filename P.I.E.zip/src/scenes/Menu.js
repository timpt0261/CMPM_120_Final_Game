class Menu extends Phaser.Scene {
    constructor() {
    super("MenuScene");
    }
}