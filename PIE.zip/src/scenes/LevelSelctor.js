class LevelSelector extends Phaser.Scene {
    constructor() {
        super("levelSelector");
    }
}